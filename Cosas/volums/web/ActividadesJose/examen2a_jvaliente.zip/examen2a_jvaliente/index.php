<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<nav>
    <nav>
        <a href="index.php"> Pagina Inicio</a>
        <a href="alta.php"> Funcion 1</a>
        <a href="cerca.php"> Funcion 2</a>
        <a href="exporta.php"> Funcion 3</a>
    </nav>
</nav>

<body>
    <h1>INDEX</h1>
</body>

</html>